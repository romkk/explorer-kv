<TS language="bg_BG" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Клик с десен бутон на мишката за промяна на адрес или етикет</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Създай нов адрес</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Копирай</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Затвори</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>Биткойн ядро</translation>
    </message>
    <message>
        <source>&amp;About Bitcoin Core</source>
        <translation>За Биткойн ядрото</translation>
    </message>
    </context>
<context>
    <name>ClientModel</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>Биткойн ядро</translation>
    </message>
    <message>
        <source>About Bitcoin Core</source>
        <translation>За Биткойн ядрото</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>Биткойн ядро</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>Биткойн ядро</translation>
    </message>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    </context>
</TS>